This program resolves domain names to **ip addresses** and also shows additional information about the domain.

it uses the boost library.

usage : ./dns_query [google.com] [facebook.com] [twitter.com]

Created by xiicode.

